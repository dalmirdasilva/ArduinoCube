//=======================================================================================
//
//  Purpose: Povide a container for the encoding of a character for display in an LED 
//           cube.
//
//  Copyright (C) 2011 Mark Stevens
//
//  This software is destributed under the MS-PL licence agreement a copy of which can
//  be found on the codeplex page http://netduinoledcontrol.codeplex.com and in the
//  Licence.txt file distributed with this project.
//
//=======================================================================================

namespace Coding4Fun.NetduinoLEDControl
{
    /// <summary>
    /// Hold the LED pattern for a character.
    /// </summary>
    class PlanarBitmap
    {
        #region Properties

        /// <summary>
        /// Letter the pattern relates to.
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Bytes representing the bit pattern for the letter.
        /// </summary>
        public byte[] DotPattern { get; private set; }

        #endregion

        #region Constructor(s)

        /// <summary>
        /// Default constructor for the instance.
        /// </summary>
        /// <param name="patternName">Name of the pattern this instance represents.</param>
        /// <param name="pattern">Bit pattern.</param>
        public PlanarBitmap(string patternName, byte[] pattern)
        {
            Name = patternName;
            DotPattern = pattern;
        }

        #endregion
    }
}
