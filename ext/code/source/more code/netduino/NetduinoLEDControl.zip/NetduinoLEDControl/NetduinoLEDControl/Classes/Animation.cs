//=======================================================================================
//
//  Purpose: Povide a an animation to dipslay in the LED cube. 
//
//  Copyright (C) 2011 Mark Stevens
//
//  This software is destributed under the MS-PL licence agreement a copy of which can
//  be found on the codeplex page http://netduinoledcontrol.codeplex.com and in the
//  Licence.txt file distributed with this project.
//
//=======================================================================================

using System.Threading;
namespace Coding4Fun.NetduinoLEDControl
{
    /// <summary>
    /// Hold the frame information for an animation to be displayed in the LED cube.
    /// </summary>
    class Animation
    {
        #region Properties

        /// <summary>
        /// Frames holding the animation sequence.
        /// </summary>
        public byte[][] Frames { get; set; }

        /// <summary>
        /// Delay (in milliseconds) between the frames.
        /// </summary>
        public int FrameDelay { get; set; }

        /// <summary>
        /// Number of times to repeat the sequence.
        /// </summary>
        public int Repeat { get; set; }

        #endregion

        #region Constuctor(s)

        /// <summary>
        /// Default constructor for an instance of the animation class.
        /// </summary>
        public Animation()
        {
            Frames = null;
            FrameDelay = 50;
            Repeat = 1;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Play this animation in the specified instance of the LED cube.
        /// </summary>
        /// <param name="cube">Instance of the LED cube to show the animation in.</param>
        /// <param name="clearCube">Should the cube be cleared before the animation is played?</param>
        public void Play(LEDCube cube, bool clearCube)
        {
            if ((Frames != null) && (Frames.Length > 0) && (Repeat > 0) && (FrameDelay > 0))
            {
                if (clearCube)
                {
                    cube.ClearCube();
                }
                for (int counter = 0; counter < Repeat; counter++)
                {
                    for (int currentFrame = 0; currentFrame < Frames.Length; currentFrame++)
                    {
                        cube.UpdateBuffer(Frames[currentFrame]);
                        Thread.Sleep(FrameDelay);
                    }
                }
            }
        }

        #endregion
    }
}
