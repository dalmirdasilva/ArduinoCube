//=======================================================================================
//
//  Purpose: Povide a container for the encoding of a character for display in an LED 
//           cube.
//
//  Copyright (C) 2011 Mark Stevens
//
//  This software is destributed under the MS-PL licence agreement a copy of which can
//  be found on the codeplex page http://netduinoledcontrol.codeplex.com and in the
//  Licence.txt file distributed with this project.
//
//=======================================================================================

namespace Coding4Fun.NetduinoLEDControl
{
    /// <summary>
    /// Hold the x, y, z coordinates of a point in the cube.
    /// </summary>
    class Point
    {
        #region Properties

        /// <summary>
        /// X Coordinate.
        /// </summary>
        public int X { get; set; }

        /// <summary>
        /// Y Coordinate.
        /// </summary>
        public int Y { get; set; }

        /// <summary>
        /// Z Coordinate.
        /// </summary>
        public int Z { get; set; }

        #endregion
    }
}
