//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resource Script.rc
//
#define IDD_DIALOG1                     101
#define IDD_WAV_INFO                    101
#define IDD_APE_INFO                    103
#define IDI_MONKEY_LEFT                 105
#define IDI_MONKEY_RIGHT                106

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        149
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
